 # DataType

| Use    | Python(np) | Python | C++               | Matlab    |
| ------ | ---------- | ------ | ----------------- | --------- |
|        |            |        |                   | int8      |
|        |            |        | CV_8U             | uint8     |
|        |            |        | CV_16S            | int16     |
|        |            |        | CV_16U            | uint16    |
| int32  |            |        | CV_32S            | int32     |
|        |            |        | CV_32U            | uint32    |
|        |            |        | CV_32S            | int64     |
|        |            |        | CV_32U            | uint64    |
|        |            |        | CV_32F            | single    |
|        |            |        | CV_64F            | double    |
|        |            |        |                   | logical   |
|        |            |        | CV_8UC1           | char      |
|        |            |        |                   | structure |
| 多维度 |            |        | CV_16UC(Channels) |           |




# Data Structure
|                    | Adv                          |     |
| ------------------ | ---------------------------- | --- |
| [[Scalar]]         | 1d array                     |     |
| [[Array]]          | Ez 2 use                     |     |
| [[Dict]]           | Dict                         |     |
| [[Tuple]]          | No change                    |     |
| [[Set]]            | Set order                    |     |
| [[Matrix]]         | High Dimensional Data        |     |
| [[Table]]          | High Dimensional Data        |     |
| [[Graph]]          | Graph theory, path, problem. |     |
| [[Tree]]           | Order, Insert, Delete        |     |
| [[Heap]]           | First-In-Last-Out            |     |
| [[Queue]]          | First-In-First-Out           |     |
| [[Iterator]]       | Iterator list                |     |
| [[Class]]          | Class                        |     |
| [[Linked List]]    | Link the element             |     |
| [[AI Layer]]       |                              |     |
| [[Dataset Loader]] | Used in AI                   |     |
