```python
def fetch_bigtable_rows(big_table, keys, other_silly_variable=None):  
    """Title must write

    Detailed explanation 

    Args:  
        first_arg: meaning

    Returns:
       datatype, used for
       
        looks like:  
        123
    """  
    pass



```