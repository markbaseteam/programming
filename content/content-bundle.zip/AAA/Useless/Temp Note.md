


Right handed Cartesian Coordinate
Object coordinate ()

[[Object Coordinate X]]: $(\mathrm{X}, \mathrm{Y}, \mathrm{Z})$

[[Camera coordinate]]: $\left(X_{C}, Y_{C}, Z_{C}\right)$

[[Coordinate System/Image coordinate]]: $(x, y)$