# 函数

 ``````ad-example
collapse: close
title: Python
icon: ra-player-shot
color: 200, 200, 200
```python
def aa(b):
	a=b
	return a
```
 ``````
 
 ``````ad-example
collapse: close
title: C++
icon: ra-player-shot
color: 200, 200, 200
```C 
float aa(float b){
	float a=b;
	return a;
}
```
 ``````