
[[#有index 且有对象]]

# 循环


``````ad-example
collapse: close
title: Python
icon: For 循环
color: 200, 200, 200
```python
for x in range(101):
    sum += x
	print(sum)
	break
	continue
```
``````


``````ad-example
collapse: close
title: Python
icon: While
color: 200, 200, 200
```python
while var == 1:
    sum += x
	print(sum)
	break
	continue
```
``````
 

 ``````ad-example
collapse: close
title: 有index, 且有对象
icon: ra-player-shot
color: 200, 200, 200
```python
for i, path in enumerate(train_images):
	break
```
 ``````
 
 ``````ad-example
collapse: close
title: C++ 有index, 且有对象
icon: ra-player-shot
color: 200, 200, 200
```C 
for (unsigned i=0; i<10; i++)
	cout<<i;
	break;
```
 ``````


# IF

 ``````ad-example
collapse: close
title: Python
icon: ra-player-shot
color: 200, 200, 200
```python
if 1:
	print(1)
elif:
else:
```
 ``````

 ``````ad-example
collapse: close
title: switch
icon: ra-player-shot
color: 200, 200, 200
```python
match subject:
    case <pattern_1>:
        <action_1>
    case <pattern_2>:
        <action_2>
    case <pattern_3>:
        <action_3>
    case _:
        <action_wildcard>
```
 ``````
 
 ``````ad-example
collapse: close
title: C++
icon: ra-player-shot
color: 200, 200, 200
```C 
if (1==1){
	print(1);
}
while (1==1){
	print(1);
}	
```
 ``````

