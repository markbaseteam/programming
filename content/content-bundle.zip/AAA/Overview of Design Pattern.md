==Component -->Program/Module==
[装饰器模式 | 教程](https://www.runoob.com/design-pattern/decorator-pattern.html)


 
|               | Pattern               | Situation                       |     |
| ------------- | --------------------- | ------------------------------- | --- |
| Create        | [[Factory Pattern]]   | ![[Factory Pattern#Abstract]]   |     |
| ^^            | [[Singleton Pattern]] | ![[Singleton Pattern#Abstract]] |     |
| ^^            | [[Builder Pattern]]   | ![[Builder Pattern#Abstract]]   |     |
| ^^            | [[Prototype Pattern]] | ![[Prototype Pattern#Abstract]] |     |
| Structure     | [[Decorator]]         | ![[Decorator#Abstract]]         |     |
| ^^            | [[Adapter Pattern]]   | ![[Adapter Pattern#Abstract]]   |     |
| Communication | [[Iterator Pattern]]  | ![[Iterator Pattern#Abstract]]  |     |
| ^^              | [[Command Pattern]]   | ![[Command Pattern#Abstract]]   |     |

