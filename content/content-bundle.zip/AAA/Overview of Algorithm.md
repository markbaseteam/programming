==X --> Y==

 计算机算法是**以一步接一步的方式来详细描述计算机如何将输入转化为所要求的输出的过程**，或者说，算法是对计算机上执行的计算过程的具体描述。
 终极参考资料：[Python/DIRECTORY.md at master · TheAlgorithms/Python · GitHub](https://github.com/TheAlgorithms/Python/blob/master/DIRECTORY.md)

# Quick Use

| Taxonomy  | Algorithm           | Given          | Wanted                                     | Purpose                  | 应用层                                        |
| --------- | ------------------- | -------------- | ------------------------------------------ | ------------------------ | --------------------------------------------- |
| Sort      | Sort                | Sequence       | Sequence                                   | 冒泡                     | [[CheckArray#Data Structure Level Operation]] |
| Search    | Search              | Database       | Index                                      | 二分查找                 | [[Check Table#Query]]                         |
| Dynamic   | Dynamic Programming | Structure      | Structure                       子问题重叠 | 避免**大量的重复计算**！ |                                               |
| Graph     | Sorting             | Sequence       | New Sequence, Tree with order              | Sort                     | networkx                                      |
| ^^        | Short path          | Weighted Graph | Spanning Tree Path(v, v<sub>i</sub>)-->min | shortest path            |                                               |
| ^^        | Search              | Graph          | Spanning Tree                              | Graph Traverse           |                                               |
| ^^        | MST                 | Weighted Graph | MST $\sum W\left(e^{\prime}\right)$-->min  | MST#Algorithm            |                                               |
| ^^        | Nearest Neighbor    | Weighted Graph | KD Tree#Shape                              | KD Tree K nearest        |                                               |
| Parameter | 牛顿法，梯度下降    | Formula   data | parameter                                  | argmax                   |     TF,pytorch                                          |
|           |                     |                |                                            |                          |                                               |
|           |                     |                |                                            |                          |                                               |



# 算法的维度

|                 |                                                      |     |
| --------------- | ---------------------------------------------------- | --- |
| Implementation  | Recursion,Iteration, Logical/推理, parallel          |     |
| Design Paradigm | exhaustive search, Divide and conquer,Search, Random |     |
| Optimization    | Linear, Dynamic, Greedy, Heuristic                   |     |
| Complexity      | O(t), O(s)                                           |     |
