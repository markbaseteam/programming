|     |                      |     |
| --- | -------------------- | --- |
| csv | df=[[pd.read_csv]]() |     |
|     |                      |     |




## File path


(filepath,tempfilename)=os.path.split(file_path)
(filename,extention)=os.path.splitext(tempfilename)

|                                |              |     |     |
| ------------------------------ | ------------ | --- | --- |
| File path to extention         | extention    |     |     |
| File path to name without ext  | filename     |     |     |
| File path to name              | tempfilename |     |     |
| File path to file address path | filepath     |     |     |
 