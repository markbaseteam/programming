Figure 是一幅画布，，每个Axe是一幅隶属于画的子图, 
可以通过subplot函数建立和子图的关系。

使用[[#Create]]创建画布，子图，和关系。

使用[[#Plot]] 绘制子图的内容

使用[[#Configuration]]设置子图的格式
## Create
| Use                                  |                          | Python                                                | Matlab | SQL | C++ |
| ------------------------------------ | ------------------------ | ----------------------------------------------------- | ------ | --- | --- |
| Create Figure alone                  | Fig是画布                | plt.figure(figsize=(7, 5))  宽，高                          |        |     |     |
| Create axe from Fig with coordinate |                          | ax=fig.add_axes([x0,y0,w,h])                          |        |     |     |
| Create axe from Fig with grid       |                          | ax3 = fig.add_subplot(223)                            |        |     |     |
| Create Figure and Axe both           | sub 是画布上绘制的子图框 | fig, ax=plt.subplots(figsize = (12, 6), nrows = 2, ncols = 2) |        |     |     |
| show                                 |                          | plt.show()                                            |        |     |     |
|                                      |                          |                                                       |        |     |     |
 

##  Plot

| Use                                                               | Python                                                               | Matlab | SQL | C++ |
| ----------------------------------------------------------------- | -------------------------------------------------------------------- | ------ | --- | --- |
| bar chart                                                         | ax.plot(x,y,"g-")                                                    |        |     |     |
| plot with <abbr title="rgb -(line) .(dot)">Color and shape</abbr> | ax.plot(x,y,"b.")                                                    |        |     |     |
| Histogram                                                         | axes.hist(np.random.rand(500), label = 'hist2', edgecolor = 'black') |        |     |     |

## Configuration

| Use      | Python                                                            | Matlab | SQL | C++ |
| -------- | ----------------------------------------------------------------- | ------ | --- | --- |
| xy range | ax.set(xlim=(1,2))                                                |        |     |     |
| xy label | ax.set(xlabel='2')                                                |        |     |     |
| title    | ax.set(title="asfas")                                             |        |     |     |
| legend         | plt.plot(x, y1, "-b", label="sine")，plt.legend(loc="upper left") |        |     |     |
 
 
 