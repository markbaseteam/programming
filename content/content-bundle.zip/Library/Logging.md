
import logging 

1. How to [[#Print Information]]
2. How to Save the Information to filef
3. 


## Print Information

Show [[#Different Level Info]]  based on [[#Control Level and Information]]

### Control Level and Information

logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.DEBUG) only show info above
%(asctime)s show time.



### Different Level Info



| Use      |                      | Python             | Matlab | SQL | C++ |
| -------- | -------------------- | ------------------ | ------ | --- | --- |
| Debug    | Only show when debug | logging.debug()    |        |     |     |
| Info     | normal               | logging.info()     |        |     |     |
| Warning  | Important            | logging.warning()  |        |     |     |
| Error    | some Shit            | logging.errorv     |        |     |     |
| Critical | Its over             | logging.critical() |        |     |     |
 
