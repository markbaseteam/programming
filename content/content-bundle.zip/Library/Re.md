# General Re Grammar

|          |                       |                    |     |     |     |
| -------- | --------------------- | ------------------ | --- | --- | --- |
| Single   | 开头                  | \^                 |     |     |     |
|          | 结束                  | \$                 |     |     |     |
|          | (1) number            | \d                 |     |     |     |
|          | (1) Non number        | \D                 |     |     |     |
|          | (n) number            | \d{3,8} \d{8}      |     |     |     |
|          | (1) number+alpha      | \w                 |     |     |     |
|          | (1) Non number+alpha  | \W                 |     |     |     |
|          | (1) Any Single char   | .                  |     |     |     |
|          | (1) Any char          | \\*                |     |     |     |
|          | (1) Space             | \s                 |     |     |     |
|          | (1) Non Space         | \S                 |     |     |     |
|          | (>1) Space            | \s+                |     |     |     |
| Logic    | 括号                  | ()                 |     |     |     |
|          | (1) Or                | `(a|b)`            |     |     |     |
|          | (1) Or                | `[ye]`             |     |     |     |
|          | (1) Not               | `[^aeiou]`         |     |     |     |
| Advanced | (1)  with condition   | `[0-9a-zA-Z\_]`    |     |     |     |
|          | (>1) with condition   | `[0-9a-zA-Z\_]+`   |     |     |     |
|          | (any)  with condition | `[0-9a-zA-Z\_]*`   |     |     |     |
|          | (n)   with condition  | `[0-9a-zA-Z\_]{4}` |     |     |     |


# Function

|   Flag           | Python |     |
| ------------ | ------ | --- |
| 忽略大小写   | re.I   |     |
| 包括换行符   | re.S   |     |
| 包括多行数据 | re.M   |     |
|              |        |     |


|          |                    | Python                                        | Pandas                      |     |     |
| -------- | ------------------ | --------------------------------------------- | --------------------------- | --- | --- |
| 单个查找 | (1) 开头匹配       | re.Match("aa","bbb",re.M\|re.I)               | Bool=df.str.match("kk")     |     |     |
| ^^       | (1) 完全匹配       | re.fullmatch("aa","bbb")                      | Bool=df.str.fullmatch("kk") |     |     |
| ^^       | (1) 任意匹配       | re.search("aa","bbb")                         | data=df.str.extract("kk")   |     |     |
| ^^       | (n) 分组匹配(日期) | re.search("(aa)(bb)","bbb")                   |                             |     |     |
| 统计     | 包含               |                                               | Bool=df.str.contains("kk")  |     |     |
| ^^       | 数量               |                                               | Bool=df.str.count("kk")     |     |     |
| 多个查找 | (n) 任意匹配       | re.findall("aa","bbb")                        |                             |     |     |
| ^^       | (n) 任意匹配迭代器 | re.finditer("aa","bbb")                       |                             |     |     |
| 分割     | 根据RE分割Str      | re.split("aa","bbb", maxsplit=3, flags=re.I)  |                             |     |     |
| 替换     | 替换               | re.sub("aa","new","bbb",count=3, flags=0)     | df.str.replace              |     |     |
| 编译复用 |                    | reg=re.compile("aa")         reg.match("bbb") |                             |     |     |
|          |                    |                                               |                             |     |     |



# Pandas Filtering