d = 


|        | List                                           |     |
| ------ | ---------------------------------------------- | --- |
| Create | {key1 : value1, key2 : value2, key3 : value3 } |     |
| Access | tinydict['Name']                               |     |
| Modify | tinydict['Age'] = 8                            |     |
| Delete | del tinydict['Name']                           |     |
| Len    | len(dict)                                      |     |
| Key       |   dict.keys()                                             |     |
