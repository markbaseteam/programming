 

## Algebra 

| Use | Python | Matlab | SQL | C++ |
| --- | ------ | ------ | --- | --- |
| +   | +      |        |     |     |
| -   | -      |        |     |     |
| *   | *      |        |     |     |
| /   | /      |        |     |     |
| %   | %      |        |     |     |
| ^   | **     | ^      |     |     |


## Logical
| Use | Python | Matlab | SQL |
| --- | ------ | ------ | --- |
| >   | >      |        |     |
| <   | <      |        |     |
| !=  | !=     |        |     |
| ==  | ==     |        |     |
| <=  | <=     |        |     |
| >=  | >=     |        |     |
| AND | and    |        |     |
| OR  | or     |        |     |
| Not | not    |        |     |


## Uary Function


| Use        | Python  | Matlab | SQL |
| ---------- | ------- | ------ | --- |
| round      | round() |        |     |
| floor      | floor() |        |     |
| ceil       | ceil()  |        |     |
| Exponents  | exp()   |        |     |
| logarithms | log()   |        |     |
| Sin        | sin()   |        |     |
| Cos        | cos()   |        |     |
| tan        | tan()   |        |     |
|            |         |        |     |
 
 
