|             |     |                            |                           |
| ----------- | --- | -------------------------- | ------------------------- |
| Create      |     | [[#Create]]                | zeros, ones, etc,.                          |
| ^^          |     | [[#Copy]]                  | copy                          |
| Property    |     | [[#Acess]]                 | Size, shape, value        |
| Calculation |     | [[#Algebric]]              | Algebric                  |
| ^^          |     | [[#Logical]]               | Logical                   |
| ^^          |     | [[#Matrix Transformation]] | Flat, reshape etc,.       |
| Structure   |     | [[#Element Modification]]  | Add, remove, change etc,.        |
| ^^          |     | [[#Holistic]]              | Such as sort, iter, etc,. |





 ```ad-example
collapse: close
title: Name Rule
icon: ra-player-shot
color: 200, 200, 200

a=function(data) will return new data, and do not change anything.

**a=func(data)** Modified Data and return data with shared view.

<u>**func(data)**</u> Modified Data and will not return data.

==a=func(data)== Modified Data and return other data.




 ```
# Create
## Create from Math

| Use                       | TorchTensor            | Python(List) | Python(Np)                          | Matlab     | C++                         | Return |
| ------------------------- | ---------------------- | ------------ | ----------------------------------- | ---------- | --------------------------- | ------ |
| Any                       |                        |              | np.array(scalar,tuple,list)         |            |                             |        |
| zeros                     | torch.zeros((x,y))     |              | zeros((3,5))                        | zeros(1,5) | Mat M1=zeros(2,3,CV_32FC1); |        |
| ones                      | torch.ones((x,y))      |              | ones((3,5))                         | ones(1,5)  | Mat M1=ones(2,3,CV_32FC1);  |        |
| full                      |                        |              | np.full((3,5),11)                   |            |                             |        |
| identity                  |                        |              | np.eye(5)                           |            |                             |        |
| 正态分布+ size(x,y)       | torch.rand((x,y))      |              | np.random.randn(x, y)               |            |                             |        |
| \[0,10)均匀整数+size(x,y) |                        |              | np.random.randint (0,10,size=(x,y ) |            |                             |        |
| \[0,10)均匀浮点+size(x,y) |                        |              | np.random.uniform (0,10,size=(x,y ) |            |                             |        |
| zeros_like                | torch.zeros_like(data) |              | zeros_like(vote)                    |            |                             |        |
| ones_Like                 | torch.ones_like(data)  |              | ones_like(vote)                     |            |                             |        |
| 正态分布Like              | torch.rand_like(dt)    |              |                                     |            |                             |        |

## Create from Copy
| Use          | Python(List) | Python(Np) | Matlab | SQL | C++    | Pytorch                 |
| ------------ | ------------ | ---------- | ------ | --- | ------ | ----------------------- |
| 浅拷贝()     | .copy(y)     |            |        |     | x=y;   |                         |
| 深拷贝(Same) | .deepcopy(y) |            |        |     | \*x=&y |                         |
| 引用         | =            | =/view     |        |     |        |                         |
| From pytorch |              | ts.numpy() |        |     |        |                         |
| From narray  |              |            |        |     |        | **torch.from_numpy(n)** |
|              |              |            |        |     |        |                         |
 
# Property
## Acess
| Use            | Pytorch   | Python(List)    | Python(Np)         | Matlab | C++                          | PYtorch    |
| -------------- | --------- | --------------- | ------------------ | ------ | ---------------------------- | ---------- |
| Get Elements 1 |           | List[0][3]      | List[0,4]          |        | M1.at\<float>(row,col)=22/7; | ts[0:4]    |
| Get Elements 2 |           | List[-1]        | List[-1]           |        |                              | List[-1]   |
| Slicing  1     |           | List[:2][4:5]   | List[:2,4:5]       |        |                              | ts[:2,4:5] |
| Slicing  2     |           | List[1:16:2]    | List[1:16:2]       |        |                              | ts[1:16:2] |
| Get Index 1    |           | List.index(elm) | np.where(arr1\==4) |        |                              |            |
| Get Index 2    |           |                 | np.where(arr1\==4) |        |                              |            |
| Length         |           | len(array)      |                    |        |                              |            |
| dimision       |           |                 | a.ndims            |        |                              |            |
| shape          | ts.shape  |                 | a.shape %%=(3,5)%% |        |                              |            |
| dtype          | ts.dtype  |                 |                    |        |                              |            |
| Device(store)  | ts.device |                 |                    |        |                              |            |

 ```ad-example
collapse: close
title: Where
icon: ra-player-shot
color: 200, 200, 200

arr = np.array([==41==, 42, ==43==, 44])  
filter = [==True==, False, ==True==, False]  

arr[filter] True索引相当于筛子，筛掉滤网对应的值。
 
 ```

# Calculation
## Algebric

| Use  | Python | Matlab | SQL | C++ | Torchtensor |
| ---- | ------ | ------ | --- | --- | ----------- |
| \+   | \+     | \+     | \+  | \+  |             |
| \-   | \-     | \-     | \-  | \-  |             |
| \*   | \*     | \*     | \*  | \*  | @           |
| /    | /      | /      | /   | /   |             |
| %    | %      | %      | %   | %   |             |
| ^    | **     | ^      | ^   | ^   |             |
| dot* | .*     | .*     |     |     | *           |
| sum  | sum()  | sum()  |     |     | ts.sum()    |
|      |        |        |     |     |             |


## Logical
| Use | Python | Matlab | SQL | C++  |
| --- | ------ | ------ | --- | ---- |
| >   | >      | >      | >   | >    |
| <   | <      | <      | <   | <    |
| !=  | !=     | !=     | !=  | !=   |
| ==  | ==     | ==     | ==  | ==   |
| <=  | <=     | <=     | <=  | <=   |
| >=  | >=     | >=     | >=  | >=   |
| AND | and    | &&     | &&  | &&   |
| OR  | or     |        |     | \|\| |
| Not | not    |        |     |      |





# Modification
## Element Modification  
| Use         | Python(List)      | Python(Np) | Matlab        | SQL | Return        |
| ----------- | ----------------- | ---------- | ------------- | --- | ------------- |
| Give Value  | List[0:1]=New     |            | List(1:1)=New |     |               |
| Append      | .append(elm)      |            |               |     | None          |
| Remove      | .remove(elm)      |            |               |     | Changed Array |
| Clear       | .clear()          |            |               |     | None          |
| Pop         | .pop(pos)         |            |               |     | Changed Array |
| Insert      | .insert(pos, elm) |            |               |     |               |
## Matrix Transformation   

| Use            | Python(List)   | Python(Np)                                  | Matlab | SQL | Pytorch                      |
| -------------- | -------------- | ------------------------------------------- | ------ | --- | ---------------------------- |
| Concatenate    | + (axis=0)     | np.concatenate((arr1, arr2), ==axis===0)    |        |     | torch.cat([ts1, ts2], dim=1) |
| vstack         |                | vstack()                                    |        |     |                              |
| hstack         |                | hstack()                                    |        |     |                              |
| split          |                | split()                                     |        |     |                              |
| Flatten 1(row) | .reshape(-1)   | .flatten(A)        **.ravel(A)**   %%view%% |        |     |                              |
| Flatten 2(col) |                | .flatten(A,'F')    **.ravel(A,'F')**        |        |     |                              |
| Reshape        | .reshape(4, 3) | .reshape((4, 3))   .reshape((4, 3),'F')     |        |     |                              |
| Matrix_Insert  |                | b[1:4,2:3]=xxx                              |        |     |                              |
| Pad            |                | np.pad(a, 1, 'constant', constant_values=0) |        |     |                              |
| Squeeze        |                | np.squeeze(A)                               |        |     |                              |
| Add Dimension  |                | (A[:,: np.newaxis])   %%to the end%%        |        |     |                              |
| Change Device  |                |                                             |        |     | ts.to("cuda")                |
|                |                |                                             |        |     |                              |

 ```ad-example
collapse: close
title: Note
icon: ra-player-shot
color: 200, 200, 200

- Axis 0 是 row, 1 是col ...etc
Concatenate: will not introduce new axis
stack: will introduce new axis for 1-d, not for 2-d
Stack是用于图像拼接的，Vstack是垂直拼接，Hstack是横向拼接， D_stack 是深度拼接

 ```


# 
## Holistic 
| Use       | Python(List)   | Python(Np)                     | Matlab | SQL | Return        |
| --------- | -------------- | ------------------------------ | ------ | --- | ------------- |
| Copy      | .copy()        |                                |        |     | Array         |
| Sort      | .sort()        | np.sort(arr)                   |        |     | Changed Array |
| Iterative | For x in List: | for idx, row in df.iterrows(): |        |     |               |
| Count     | .count(elm)    |                                |        |     | Scalar        |

