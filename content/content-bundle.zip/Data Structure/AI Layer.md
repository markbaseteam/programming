| Name                      | Left                 | Right                                        | Pytorch                                   |
| ------------------------- | -------------------- | -------------------------------------------- | ----------------------------------------- |
| Perceptron Layer          | y<sup>1*m</sup>      | x<sup>1*n</sup>                              |                                           |
| [[Convolution]]           | y<sup>m\*n\*nk</sup> | x<sup>m\*n\*c</sup>, k<sup>nk\*k\*k\*c</sup> | self.conv1 =torch.nn.Conv2d(c, nk, k)     |
| [[Pooling]]               |                      |                                              |                                           |
| [[Batch Norm Layer]]      |                      |                                              |                                           |
| Inception                 |                      |                                              |                                           |
| Dropout Layer             | y<sup>p\*q</sup>     | x<sup>m\*n</sup>                             |                                           |
| [[Fully Connected Layer]] |                      |                                              |                                           |
| Linear                    | y<sup>n</sup>        | x<sup>m</sup>                                | self.linear= torch.nn.Linear(x, y)    |
| Activation                |                      |                                              | self.activation =torch.nn.ReLU()          |
| Softmax                   |                      |                                              | self.softmax = torch.nn.Softmax()         |
|                           |                      |                                              | self.pooling=torch.functional.maxpool2d() |
|                           |                      |                                              |                                           |

















**PYTORCH 模板**
``` python
class NeuralNetwork(nn.Module):
    def __init__(self):
        super(NeuralNetwork, self).__init__()

        self.conv1 =torch.nn.Conv2d(1, 6, 4,padding="same") 
        self.flatten = nn.Flatten()
        self.linear1=nn.Linear(28*28*6, 10)
        
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(28*28*6, 512),
            nn.ReLU(),
            nn.Linear(512, 512),
            nn.ReLU(),
            nn.Linear(512, 10)
        )

    def forward(self, x):
        x=self.conv1(x)
        x=self.conv2(x)
        x = self.flatten(x)
        logits = self.linear1(x)
        
        return logits

model = NeuralNetwork().to(device)
```