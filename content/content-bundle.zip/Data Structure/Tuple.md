Same as [[Array]]

But cannot be change.