 
| Usage     | Iterator     | Generator    |
| --------- | ------------ | ------------ |
| Create    | iter(list)   | it=ge()      |
| Access    | next(it)     | next(it)     |
| Iteration | for x in it: | for x in it: |

Create from Class
_F_(0)=0，_F_(1)=1, _F_(n)=_F_(n - 1)+_F_(n - 2)
```PYTHON
class Fib: 
	def __init__(self): 
		self.prev = 0 
		self.curr = 1 
	def __iter__(self): 
		return self 
	def __next__(self): 
		self.curr, self.prev = self.prev + self.curr, self.curr 
		return self.curr 


class Fib: 
	def __init__(self,list): 
		self.LIST = list 
		self.index=0
	def __iter__(self): 
	self.index=self.index+1
		return list[self.index]

	def __next__(self): 
		self.index=self.index+1
		return list[self.index]



fib = Fib() 
for i in range(10): 
	print(next(fib))
```


Create from Generator

```
def fib(): 
	prev, curr = 0, 1 
	while True: 
		yield curr 
		curr, prev = prev + curr, curr
f = fib() 
for i in range(10): 
	print(next(f))
```