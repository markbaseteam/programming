 ```ad-example
collapse: close
title: Name Rule
icon: ra-player-shot
color: 200, 200, 200

copy()
**copy(view)** return view

<u>**copy(view)**</u> return view but do not return value

 ```

# Create

| Taxonomy         | Use                       | TorchTensor             | Python(List) | Python(Np)                           | Pandas                               | Matlab     |     | C++                                                            | Return |
| ---------------- | ------------------------- | ----------------------- | ------------ | ------------------------------------ | ------------------------------------ | ---------- | --- | -------------------------------------------------------------- | ------ |
| Create from Math | Empty                     |                         |              | np.array(256,256)                    | df = pd.DataFrame(columns=['A','B']) |            |     | Mat(3, 3, CV_8UC3)                                             |        |
| ^^               | Any                       |                         |              | np.array([1,2,3,4,5])                |                                      |            |     | `Mat C = (Mat_<double>(3,3) << 0, -1, 0, -1, 5, -1, 0, -1, 0)` |        |
| ^^               | ^^                        | ^^                      | ^^           | ^^                                   | ^^                                   | ^^         | ^^  | `Mat(3,3,CV_64F, {{a, b, c}, {d, e, f}, {g, h, i}})`           |        |
| ^^               | zeros                     | torch.zeros((x,y))      |              | zeros((3,5))                         |                                      | zeros(1,5) |     | Mat M1=zeros(2,3,CV_32FC1);                                    |        |
| ^^               | ones                      | torch.ones((x,y))       |              | ones((3,5))                          |                                      | ones(1,5)  |     | Mat M1=ones(2,3,CV_32FC1);                                     |        |
| ^^               | full                      |                         |              | np.full((3,5),11)                    |                                      |            |     | Mat M(2,2, CV_8UC3, Scalar(0,0,255));                          |        |
| ^^               | identity                  |                         |              | np.eye(5)                            |                                      |            |     | Mat E = Mat::eye(4, 4,CV_64F);                                 |        |
| ^^               | 正态分布+ size(x,y)       | torch.rand((x,y))       |              | np.random.randn(x, y)                |                                      |            |     |                                                                |        |
| ^^               | \[0,10)均匀整数+size(x,y) |                         |              | np.random.randint (0,10,size=(x,y )) |                                      |            |     | randu(Mat(3, 3, CV_8UC3), Scalar::all(0), Scalar::all(255));   |        |
| ^^               | \[0,10)均匀浮点+size(x,y) |                         |              | np.random.uniform (0,10,size=(x,y )) |                                      |            |     |                                                                |        |
| ^^               | zeros_like                | torch.zeros_like(data)  |              | zeros_like(vote)                     |                                      |            |     |                                                                |        |
| ^^               | ones_Like                 | torch.ones_like(data)   |              | ones_like(vote)                      |                                      |            |     |                                                                |        |
| ^^               | 正态分布Like              | torch.rand_like(dt)     |              |                                      |                                      |            |     |                                                                |        |
| Create from Copy | 浅拷贝(列表——同址不同名)  |                         | .copy(y)     |                                      |                                      |            |     | x=y;                                                           |        |
| ^^               | 深拷贝(不同址名)          |                         | .deepcopy(y) |                                      |                                      |            |     | \*x=&y  b.clone();                                             |        |
| ^^               | 引用(同址不同名)          |                         | =            | =/view                               |                                      |            |     |                                                                |        |
| ^^               | From pytorch              |                         |              | ts.numpy()                           |                                      |            |     |                                                                |        |
| ^^               | From narray               | **torch.from_numpy(n)** |              |                                      |                                      |            |     |                                                                |        |
| ^^               | From csv                  |                         |              |                                      | df=[[pd.read_csv]]()                 |            |     |                                                                |        |
 

# Property  

## Meta

| Taxonoy |     | Use           | Python(List)     | Python(Np)         | Python(pd)       | Matlab | C++                          | PYtorch |
| ------- | --- | ------------- | ---------------- | ------------------ | ---------------- | ------ | ---------------------------- | ------- |
| Shape   |     | shape         |                  | a.shape %%=(3,5)%% |                  |        |  .cols    .rows                        |         |
| ^^      |     | Length        | len(array)       |                    |                  |        |                              |         |
| ^^      |     | dimision      |                  | a.ndims            |                  |        |                              |         |
| Table   |     | dtype         |                  |                    |                  |        |                              |         |
| ^^      |     | Device(store) |                  |                    |                  |        |                              |         |
| ^^      |     | view(example) |                  |                    | data.head()      |        |                              |         |
| ^^      |     | Get Col list  |                  |                    | train_df.columns |        |                              |         |
| ^^      |     |               |                  |                    |                  |        |                              |         |

## Query

| Use                           | Python(List)       | Numpy                 | Python(pd)                                                             | C++                            | Matlab | SQL | C++      | Return |
| ----------------------------- | ------------------ | --------------------- | ---------------------------------------------------------------------- | ------------------------------ | ------ | --- | -------- | ------ |
| Select by location            | `List[:2][4:-1:2]` | `List[:2,4:-1:2]`     | `df.iloc[:2,4:-1:2]`                                                   | `M1.at\<float>(row,col)=22/7;` |        |     |          |        |
| Select by label               |                    |                       | `df.loc['row1',['col1','col2']]  / df.col1 /  titanic[["Age", "Sex"]]` |                                |        |     |          |        |
| Select by Algebraic by column |                    |                       | `df["new"]=df["old"]^2  ,  df["ew"]=df["old"].str.len()`               |                                |        |     |          |        |
| Select by Algebraic by row    |                    |                       | `df.apply(lambda x: x[b]+1 )`                                          |                                |        |     |          |        |
| Select by Aggregation         |                    |                       | `g = df.a.sum()  See [[#Aggregation]]`                                 |                                |        |     |          |        |
| Select by Sampling            |                    |                       | `pd.sample(n=500)`                                                     |                                |        |     |          |        |
| Select by Sort                |                    |                       | `df.sort_values(by='col1', ascending=False)`                           |                                |        |     |          |        |
| Search Index by Value         | List.index(elm)    | np.argwhere(arr1\==4) | `b[b == 1].stack().index.tolist()`                                     |                                |        |     | A.row(1) |        |
| GroupBy                       |                    |                       | g = df.groupby("class").size() See [[#Aggregation]]                    |                                |        |     |          |        |
| GroupBy (非聚合合并)          |                    |                       | df.pivot(index='ind', columns='class', values=['rating']).fillna(0)    |                                |        |     |          |        |
| Resample  **Date**            |                    |                       | df=df.resample('d').sum()                                              |                                |        |     |          |        |
| Where                         |                    |                       | df=df[df["a"] > 10] or df.iloc[1:3] or df.loc[df["a"] > 10]            |                                |        |     |          |        |
|                               |                    |                       |                                                                        |                                |        |     |          |        |

#### Aggregation
 ```ad-example
collapse: close
title: Aggregation
icon: ra-player-shot
color: 200, 200, 200
sum() count() size() median()  .agg({"a": np.mean,"a": np.count}       )
 ```




# Calculation
## Algebric

| Use  | Python | Matlab | SQL | C++ | Torchtensor |
| ---- | ------ | ------ | --- | --- | ----------- |
| \+   | \+     | \+     | \+  | \+  |             |
| \-   | \-     | \-     | \-  | \-  |             |
| \*   | \*     | \*     | \*  | \*  | @           |
| /    | /      | /      | /   | /   |             |
| %    | %      | %      | %   | %   |             |
| ^    | **     | ^      | ^   | ^   |             |
| dot* | .*     | .*     |     |     | *           |
| sum  | sum()  | sum()  |     |     | ts.sum()    |
|      |        |        |     |     |             |


## Logical
| Use | Python | Matlab | SQL | C++  |
| --- | ------ | ------ | --- | ---- |
| >   | >      | >      | >   | >    |
| <   | <      | <      | <   | <    |
| !=  | !=     | !=     | !=  | !=   |
| ==  | ==     | ==     | ==  | ==   |
| <=  | <=     | <=     | <=  | <=   |
| >=  | >=     | >=     | >=  | >=   |
| AND | and    | &&     | &&  | &&   |
| OR  | or     |        |     | \|\| |
| Not | not    |        |     |      |


# Modification

## Element Modify
 
| Use           | Python(List) | Python(pd)                                              | Matlab | SQL | C++ |     |                           |
| ------------- | ------------ | ------------------------------------------------------- | ------ | --- | --- | --- | ------------------------- |
| Alter         |              | df = df.rename(columns={'oldName1': 'newName1',})       |        |     |     |     |                           |
| Drop          |              | `df.drop(['B', 'C'], axis=1)    del df['column_name']`` |        |     |     |     |                           |
| Save          |              | `df=[[pd.to_csv]]("path")``                             |        |     |     |     |                           |
| Add Row       |              |                                                         |        |     |     |     |                           |
| Add Column    |              |                                                         |        |     |     |     |                           |
| Delete Column |              | `df.drop(['depression',"anxiety","stress"], axis=1)``   |        |     |     |     |                           |
| Delete Row    |              |                                                         |        |     |     |     |                           |
| Update row    |              |                                                         |        |     | Old.col(7).copyTo(NEW);     |     |                           |
| Update ele    |              | `df.loc[:, 'max_speed'] = 30`                           |        |     |  M.at\<double>(i,j) += 1.f;   |     |  |



| Use         | Python(List) | Python(pd)                                   | Matlab | SQL | Return |
| ----------- | ------------ | -------------------------------------------- | ------ | --- | ------ |
| Primary Key |              | itself=df.set_index('xxx'/['year', 'month']) |        |     |        |
|             |              |                                              |        |     |        |

## Matrix Transformation   

| Use             | Python(List)   | Python(Np)                                  | pandas                       | Matlab | SQL | Pytorch                      | C++         |
| --------------- | -------------- | ------------------------------------------- | ---------------------------- | ------ | --- | ---------------------------- | ----------- |
| Concatenate     | + (axis=0)     | np.concatenate((arr1, arr2), ==axis===0)    | pd.concat([df1,df2], axis=1) |        |     | torch.cat([ts1, ts2], dim=1) |             |
| vstack          |                | vstack()                                    |                              |        |     |                              |             |
| hstack          |                | hstack()                                    |                              |        |     |                              |             |
| split           |                | split()                                     |                              |        |     |                              |             |
| 读书一样Flatten | .reshape(-1)   | a.flatten()                                 |                              |        |     |                              |             |
| 反向读书Reshape | .reshape(4, 3) | .reshape((4, 3))   .reshape((4, 3),'F')     |                              |        |     |                              | .reshape(4,3) |
| Matrix_Insert   |                | b[1:4,2:3]=xxx                              |                              |        |     |                              |             |
| Pad             |                | np.pad(a, 1, 'constant', constant_values=0) |                              |        |     |                              |             |
| Squeeze         |                | np.squeeze(A)                               |                              |        |     |                              |             |
| Add Dimension   |                | (A[:,: np.newaxis])   %%to the end%%        |                              |        |     |                              |             |
| Change Device   |                |                                             |                              |        |     | ts.to("cuda")                |             |
|                 |                |                                             |                              |        |     |                              |             |


# Structure
## Join

| Use          | Python(List) | Python(pd)                                   | Matlab | SQL | Return |
| ------------ | ------------ | -------------------------------------------- | ------ | --- | ------ |
| Join         |              | jd = df.join(df2)                            |        |     |        |
| left Join    |              | df=pd.merge(df1, df2,left_on=1, right_on=1, how="left")  |        |     |        |
| Right Join   |              | df=pd.merge(df1, df2, on="key", how="right") |        |     |        |
| Outer Join   |              | dfp=d.merge(df1, df2, on="key", how="outer") |        |     |        |
| Natural Join |              | df=pd.merge(df1, df2, on="key")              |        |     |        |
| Union        |              | pd.concat([df1, df2])                        |        |     |        |
|              |              |                                              |        |     |        |
## Holistic 
| Use       | Python(List)   | Python(Np)   | Pandas                                       | Matlab | SQL | Return        |
| --------- | -------------- | ------------ | -------------------------------------------- | ------ | --- | ------------- |
| Copy      | .copy()        |              |                                              |        |     | Array         |
| Sort      | .sort()        | np.sort(arr) | df.sort_values(by='rating', ascending=False) |        |     | Changed Array |
| Iterative | For x in List: |              | for idx, row in df.iterrows():               |        |     |               |
| Count     | .count(elm)    |              |                                              |        |     | Scalar        |
