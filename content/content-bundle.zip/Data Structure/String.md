"For only {price:.2f} dollars!".format(price=123)


aaa.split()



"hELLO wORLD"

A= ["H",E，l l o, w o r l d]

A[1]