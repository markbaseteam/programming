```python
import torch
from torch.utils.data import Dataset
from torchvision import datasets
from torchvision.transforms import ToTensor
import matplotlib.pyplot as plt 
```


How does a Fourier transform looks like.
## Create Sample Data


|       | Pytorch                                                                                             |     |     |
| ----- | --------------------------------------------------------------------------------------------------- | --- | --- |
| MNIST | training_data = datasets.FashionMNIST( root="data", train=True,download=True,transform=ToTensor() ) |     |     |
|       |                                                                                                     |     |     |


## GetI Genarator


```python
train_dataloader = DataLoader(training_data, batch_size=64, shuffle=True)
train_tensor_x, train_tensor_y = next(iter(train_dataloader))
```

我的决策是由什么样的利益，行为决定的。
冷静思考，冷静，冷静。
还有，就是谈判的意义在于什么，
如何和低智商的人有效谈判，有效谈判的意义。绝不是一味的摆事实，而是，讨论情绪？不对，知己知彼。换位双倍换位思考
人要有底线
语言要表达清楚。不要太严肃，如何和女人交流。预则立，一定要预测‘’‘接受最坏的打算。
什么是交流，能够抵达的信息
，。，情绪，人

什么是思考，什么是规划。以及，





## Visualization
```python
 
# Pytorch Loader  
# Tensorflow Loader


figure = plt.figure(figsize=(8, 8))
cols, rows = 3, 3
for i in range(1, cols * rows + 1):


    # Pytorch Loader
    sample_idx = torch.randint(len(train_data), size=(1,)).item() % Pytorch Loader


    # Pytorch Loader
    sample_idx = torch.randint(len(train_data), size=(1,)).item() % Pytorch Loader


    img, label = train_data[sample_idx]
    figure.add_subplot(rows, cols, i)
    plt.title(labels_map[label])
    plt.axis("off")
    plt.imshow(img.squeeze(), cmap="gray")
plt.show()
```
