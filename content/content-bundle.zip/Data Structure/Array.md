[[#Algebric]]
[[#Logical]]

[[#Acess]]
[[#Copy]]

[[#Create]]
[[#Element Based Modification]]
[[#Array Based Modification]]

[[#Data Structure Level Operation]]
# Create
| Use                       | Python(List)          | Python(Np)                       | Pandas.Series              | SQL | C++              |
| ------------------------- | --------------------- | -------------------------------- | -------------------------- | --- | ---------------- |
| Empty                     |                       |                                  |                            |     | vector\<float> v |
| [0,10]                    | Range(11)             | not common                       | not common                 |     |                  |
| Any                       | [1, 2, 3]             | np.array(s[1,2,3])               | pd.Series([1,2,3])         |     |                  |
| zeros                     | [0,0,0]               | np.zeros(5)                      | pd.Series(np.zeros((5)))   |     |                  |
| ones                      | [1,1,1]               | np.ones(3)                       | pd.Series(Np)              |     |                  |
| zeros_like                | ...                   | np.zeros_like(vote)              | pd.Series(Np)              |     |                  |
| \[0,10)均匀整数+size(x,y) | ...                   | np.random.randint(0,10,size=(5)) | pd.Series(Np)              |     |                  |
| \[0,10)均匀浮点+size(x,y) | ...                   | np.random.uniform(0,10,size=(8)) | pd.Series(Np)              |     |                  |
| 正态分布+ size(x,y)       | ...                   | np.random.normal(μ,σ,5)          | pd.Series(Np)              |     |                  |
| 列表生成器                | [type(x) for x in df] | np.apply_over_axes(np.sum, a, 0) | df.apply(np.sqrt , axis=1) |     |                  |
|                           |                       |                                  |                            |     |                  |

## Copy
| Use          | Python(List) | Python(Np) | Pandas.Series | SQL | C++    |
| ------------ | ------------ | ---------- | ------ | --- | ------ |
| 浅拷贝()     | .copy(y)     |            |        |     | x=y;   |
| 深拷贝(Same) | .deepcopy(y) |            |        |     | \*x=&y |
| 引用         | =            | =/view     |        |     |        |
 

| Use       | Python(List) | Python(Np) | Pandas.Series | SQL |
| --------- | ------------ | ---------- | ------ | --- |
| dimension | .ndim        |            |        |     |
| shape     |              | arr.shape  |        |     |
|           |              |            |        |     |



# Acess
| Use            | Python(List)         | Python(Np)           | Pandas.Series        | SQL |
| -------------- | -------------------- | -------------------- | -------------------- | --- |
| Index          | List[0]              | List[0]              | df[1]                |     |
| Index          | List[-1]             | List[-1]             | List[-1]             |     |
| Slicing        | List[:2:2] List[1:2] | List[:2:2] List[1:2] | List[:2:2] List[1:2] |     |
| Length         | len(array)           | len(array)           | len(array)           |     |
| Search (index) | List.index(elm)      | np.where(arr1\==4)   | df[df == 7].index[0] |     |
| Count          | .count(elm)          | ...                  | ...                  |     |


 ```ad-example
collapse: close
title: Where
icon: ra-player-shot
color: 200, 200, 200

arr = np.array([==41==, 42, ==43==, 44])  
filter = [==True==, False, ==True==, False]  

arr[filter] True索引相当于筛子，筛掉滤网对应的值。
 
 ```

# Calculation
## Algebric

| Use | Python | Pandas.Series | SQL | C++ |
| --- | ------ | ------------- | --- | --- |
| \+  | \+     |  \+             |     |     |
| \-  | \-     |  \-              |     |     |
| \*  | \*     |  \*              |     |     |
| \/  | \/     |  \/             |     |     |
| %   | %      |  %             |     |     |
| ^   | **     |   **             |     |     |


## Logical
| Use | Python | Pandas.Series | SQL |
| --- | ------ | ------------- | --- |
| >   | >      | >             |     |
| <   | <      | <             |     |
| !=  | !=     | !=            |     |
| ==  | ==     | ==            |     |
| <=  | <=     | <=            |     |
|\>=  | \>=     | \>=            |     |
| AND | and    | &             |     |
| OR  | or     | \|            |     |
| Not | not    | ~             |     |

## Set
| Use  | Python                                              | Pandas.Series | SQL |
| ---- | --------------------------------------------------- | ------------- | --- |
| 余集 | cat_list= [x for x in collist if x not in num_list] |               |     |
| 并集 |                                                     |               |     |
| 交集 |                                                     |               |     |


# Modification
## Element Based Modification  
| Use         | Python(List)      | Python(Np)           | Pandas.Series             | SQL | C++        |
| ----------- | ----------------- | -------------------- | ------------------------- | --- | ------------- |
| Give Value  | List[0:1]=New     | List[0:1]=New        | List[0:1]=New             |     |               |
| Append      | .append(elm)      | numpy.append(a, ele) | df.append(df2)            |     | v.push_back(2)          |
| Remove(ele) | .remove(elm)      | arr[arr != 6]        | =df.drop(df\==ele,axis=0) |     | Changed Array |
| Remove(Ind) | del a[-1]         | numpy.delete(a, ele) | =df.drop([1],axis=0)      |     |               |
| Pop         | .pop(pos)         | a[:-1]               | a[:-1]                    |     | Changed Array |
| Insert      | .insert(pos, elm) | np.insert(b, ind, 3) | df.insert(ind,value)      |     |               |
|             |                   |                      |                           |     |               |



## Array Based Modification  

| Use         | Python(List) | Python(Np)                              | Pandas.Series                | SQL | Return |
| ----------- | ------------ | --------------------------------------- | ---------------------------- | --- | ------ |
| Concatenate | +            | +, np.concatenate((arr1, arr2), axis=1) | pd.concat([df1,df2], axis=1) |     |        |
| Split       | ...          | np.split()                              | ...                          |     |        |
| Unique      | set([ ])     | numpy.unique(ar)                        | df.unique()                  |     |        |
| Clear       | .clear()     | np.delete()                             | del(df)                      |     | None   |

 ```ad-example
collapse: close
title: Note
icon: ra-player-shot
color: 200, 200, 200
Concatenate相当于[1,2]+[1,2]
Stack是用于图像拼接的，Vstack是垂直拼接，Hstack是横向拼接， D_stack 是深度拼接
 ```

#  Data Structure Level Operation
| Use        | Python(List)                       | Python(Np)                       | Pandas                     | Matlab | SQL | Return        |
| ---------- | ---------------------------------- | -------------------------------- | -------------------------- | ------ | --- | ------------- |
| Sort       | .sort()                            | np.sort(arr)                     | df.sort()                  |        |     | Changed Array |
| Iterative  | For x in List:                     | For x in List:                   | For x in List:             |        |     |               |
| 列表生成器 | [type(x) for x in df]              | np.apply_over_axes(np.sum, a, 0) | df.apply(np.sqrt , axis=1) |        |     |               |
| Filtering  | [x^2 for x in "123" if x == "111"] | arr[arr != 6]                    | df["col"][df["col"]<1]     |        |     |               |
| map        | list(map(square, [1,2,3,4,5]))     | Nan                              | df.map(np.sqrt)            |        |     |               |
