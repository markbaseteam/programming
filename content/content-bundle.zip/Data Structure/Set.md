
# Normal
|        | Set                   |     |
| ------ | --------------------- | --- |
| Create | {value01,value02,...} |     |
| Add    | s.add( x )            |     |
|  delete      | s.remove( x )         |     |
|        |                       |     |

# Math
|           |                                       |
| --------- | ------------------------------------- |
| Union     | set1.union(set2, set3...)    \|         |
| Intersect | set1.intersection(set2, set3 ... )  & |
| diff      | x.difference(y)        -              |
|           |                                       |