# Create
## 创建最复杂单类
```python

class MyClass: 
	"""一个简单的类实例"""
	property1 = 12345         # !!!!
	__private_property1 = 0      # !!!!
	def __init__(self, para1, para2):     # !!!!	
		self.para1=para2    # !!!!
		self.para2=para2
		print("任意操作")   # !!!!

	def __del__(self):
		print("I am died")
	def __add__(self, other):
		print("两个我")

	def class_func1(self):     # !!!!
		return 'hello world'



cls = MyClass(1, 2)
cls.property1
cls.class_func1()
del cls
```

## Family
```python
class people():
	name = '' 
	__age = 0
	def __init__(self,n,a): 
		people
		self.name = n    
		self.__age = a 
	def self_introduction(self): 
		print(self.name)
	def talkage(self):   
		print(self.__age)

class soul():
	type = "pure"
	def __init__(self,t):     
		self.type=t

class xhs_User(Father,soul):    # !!!!
	xhs_ID =  1 
	def __init__(self,n,a,x,t):     # !!!!
		people.__init__(self,n,a)
		soul.__init__(self,t)    # !!!!

		self.xhs_ID = x     # !!!!
	def self_introduction(self):   # Overwrite
		print(self.name)
		print(self.xhs_ID)
		print(self.type)
 
```