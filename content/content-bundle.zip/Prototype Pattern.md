 
# Abstract
Do: 用对原型实例Clone替代初始化
Fix: 初始化耗时
==When: 当一个系统应该独立于它的产品创建，构成和表示时==

