 
# Abstract
Do: 继承或依赖进行适配类
Fix: 不适配，重写
==When: 接口转换==

