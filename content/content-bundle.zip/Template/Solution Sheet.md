 ```ad-example
collapse: open
title: Solution Sheet
icon: ra-player-shot
color: 200, 200, 200

 ```