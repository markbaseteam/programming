 
<div  align="center"><progress align="right" class="progress" value="15" max="100" style=" align:center;font-size:70px;">15%</progress></div>

 