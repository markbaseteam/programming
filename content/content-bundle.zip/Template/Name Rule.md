 ```ad-example
collapse: close
title: Name Rule
icon: ra-player-shot
color: 200, 200, 200

a=function(data) will return, and do not change view.
**a=func(data)** will return, but modify data

<u>**func(data)**</u> will only modify data

 ```