```ad-example
collapse: open
title: Description
icon: ra-player-shot
color: 200, 200, 200
 
```
