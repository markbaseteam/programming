 ```ad-example
collapse: close
title: Where
icon: ra-player-shot
color: 200, 200, 200

 ```