```ad-example
collapse: close
title: Answer
icon: ra-player-shot
color: 200, 200, 200
Select .gid as tree [[Group by]]
```
