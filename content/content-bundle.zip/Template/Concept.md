### Classification
Belong to:

includes:
### Define


```ad-note
collapse: open

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla et euismod nulla.
```
 
### Example