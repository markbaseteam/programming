 
# Abstract
Do: 创建迭代器
Fix: 省时间，暴漏对象
==When: 封装地，遍历一个聚合对象==

