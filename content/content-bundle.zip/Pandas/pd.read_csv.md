[pandas.read_csv — pandas 1.4.3 documentation](https://pandas.pydata.org/docs/reference/api/pandas.read_csv.html)

```python
df=pd.read_csv("str",
sep=',',header=0, names=None, index_col=None, usecols=None  %default
          %optional			
)
```


Output:

|     | Format    |
| --- | --------- |
| df  | dataframe |
|     |           |

 
Input:

|                    | format     | Default        | Explain      |
| ------------------ | ---------- | -------------- | ------------ |
| filepath_or_buffer | str        |                | 输入文件地址 |
| sep                | str        | ,              | 分隔符       |
| header             | int， None | 偏向于指定表头 | 指定表头     |
| names              | [str]      | None           | 自定义表头   |
| index_col          | int , None | None           | 指定索引     |
| usecols            | [str, int] |                |              |
| on_bad_lines       | ='skip'    |                |   跳过坏蛋行           |



