
[参考资料](https://www.cnblogs.com/yssjun/p/11102162.html)
# Abstract
Do: 封装和管理对象的创建，是一种创建型模式
Fix: 接口混乱
==When: 根据条件创建不同实例==